# Push notu

Bu depo GitHub'da **`tnygnz/suomi-kartat`** altında yayınlanır. Yerel dal adı
Freebuff çalışma alanına özgüdür (`freebuff/<oturum>`); uzakta dal **`main`**
olur.

## Tek komut

Depo kökünde, `git status` temizken:

```bash
git push -u origin HEAD:main
```

`HEAD:main` yerel dalın adını uzakta `main` yapar. Depo boşken uzak dal
oluşur; `-u` sonraki `push`/`pull` komutlarını sadeleştirir. Beklenen çıktı:
`main -> main (new branch)`.

## Kimlik doğrulama

1. **HTTPS + kişisel erişim anahtarı** — GitHub → Settings → Developer
   settings → Tokens (classic), `repo` kapsamı. Push'ta kullanıcı adı
   `tnygnz`, parola yerine token. Kalıcı için `git config credential.helper
   store` (token düz metin saklanır; paylaşılan makinede kullanma).
2. **`gh` CLI** — `gh auth login` → `https://github.com` → tarayıcıyla giriş,
   ardından aynı push komutu.
3. **SSH** — `git remote set-url origin git@github.com:tnygnz/suomi-kartat.git`,
   anahtar GitHub'da tanımlı olmalı; parolalı anahtar için `ssh-agent`.

## Uzak depoya erişim yoksa

Yedek bundle'dan klonlayıp kendi kimliğinle gönder:

```bash
git clone sanat-backup-2026-11-04.bundle sanat
cd sanat
git remote add origin https://github.com/tnygnz/suomi-kartat.git
git push -u origin HEAD:main
```

Alternatif: `patches/` altındaki dosyalar `git am patches/*.patch` ile
uygulanır.

## Push edilmemesi gerekenler

`cert/` (TLS özel anahtarı), `*.bundle` ve `patches/` kök `.gitignore` ile
izleme dışında; `sanat/sanat-server.log` ve `.pid` de `sanat/.gitignore`
kapsamında. Push öncesi `git status --porcelain` çıktısı boş olmalı.

## İlk push'tan sonra

GitHub'da varsayılan dalın `main` olduğunu bir kez kontrol et.
